<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<style>



body {
    background-color: #c4c1c0
}

.padding {
    padding: 2rem !important
}

.card {
    margin-bottom: 30px;
    border: none;
    -webkit-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
    -moz-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
    box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22)
}

.card-header {
    background-color: #fff;
    border-bottom: 1px solid #e6e6f2
}

h3 {
    font-size: 20px
}

h5 {
    font-size: 15px;
    line-height: 26px;
    color: #3d405c;
    margin: 0px 0px 15px 0px;
    font-family: 'Circular Std Medium'
}

.text-dark {
    color: #3d405c !important
}



</style>
</head>
<body>


<div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 padding">
     <div class="card">
         <div class="card-header p-4">
             <a class="pt-2 d-inline-block" href="index.html" data-abc="true">ZeeGroup.com</a>
             <div class="float-right">
                 <h3 class="mb-0">Invoice no: # <?php
  echo $_POST["invoice"];
  ?></h3>
               
			   Date:<?php
  echo $_POST["date"];
  ?>
             </div>
         </div>
         <div class="card-body">
             <div class="row mb-4">
                 <div class="col-sm-6">
                     <h5 class="mb-3">From:</h5>
                     <h3 class="text-dark mb-1">ZeeGroup of Comapnies</h3>
                     <div>29, Gyor Street</div>
                     <div>Hunagry,Dunaujvaros 2400</div>
                     <div>Email: contact@zeegroup.com</div>
                     <div>Phone: +36 9896 989 089</div>
                 </div>
                 <div class="col-sm-6 ">
                     <h5 class="mb-3">To:</h5>
                     <h3 class="text-dark mb-1"><?php
  echo $_POST["name"];
  ?></h3>
                     
                     <div>Email: <?php
  echo $_POST["email"];
  ?></div>
                     <div>Phone: <?php
  echo $_POST["ph"];
  ?></div>
                 </div>
             </div>
             
			 <div class="table-responsive-sm">
                 <table class="table table-striped">
                     <thead>
                         <tr>
						 <hr>
                             <th class="center">#</th>
                             <th>Item</th>
                            
                            
                            
                            
                             <th class="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; Amount</th>
                         </tr>
                     </thead>
					<hr>
                     <tbody>
                         
                       
                         
                         <tr>
                             
                             <td class="left"></td>
                             <td class="left">Total Costs</td>
                             
                             <td class="left"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php
  echo $_POST["subtotal"];
  ?></td>
                             <br>
							 <br>
							 <br>
							 <br>
                         </tr>
                     </tbody>
                 </table>
             </div>
             <div class="row">
                 <div class="col-lg-4 col-sm-5">
                 </div>
                 <div class="col-lg-4 col-sm-5 ml-auto">
                     <table class="table table-clear">
                         <tbody>
                             <tr>
							 <br>
                                 <td class="right">
                                     <strong class="text-dark">&nbsp;&nbsp;&nbsp; Subtotal</strong>
                                 </td>
                                 <td class="right"> &nbsp;&nbsp; &nbsp; &nbsp;$<?php
  echo $_POST["subtotal"];
  ?></td>
                             </tr>
                             
                             <tr>
                                <br>
								
                             <tr>
							 
                                 <td class="left">
                                     <strong class="text-dark">&nbsp;&nbsp;&nbsp;&nbsp; Total</strong> </td>
                                 <td class="left">
								 
                                     <strong class="text-dark"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $<?php
  echo $_POST["total"];
  ?></strong>
                                 </td>
                             </tr>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
		 
		 
		 <br>
		 <br>
		 <br>
		 <br>
		 <br>
		 <hr>
         <div class="card-footer bg-white">
             <p class="mb-0">ZeeGroup.Com, Hunagry, Dunaujvaros,2400</p>
         </div>
     </div>
 </div>